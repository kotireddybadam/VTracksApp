package com.itok.vtracksapp.Bean

data class  SchoolInfo ( var schoolName: String,
                         var mailId: String,
                         var contactNo: String,
                         var Address: String
)