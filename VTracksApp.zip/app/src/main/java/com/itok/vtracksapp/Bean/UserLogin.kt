package com.itok.vtracksapp.Bean

data class UserLogin( var username: String,
                     var password: String,
                     var userrole: String)