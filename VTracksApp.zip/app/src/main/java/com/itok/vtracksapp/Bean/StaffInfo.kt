package com.itok.vtracksapp.Bean

data class  StaffInfo ( var firstName: String,
                         var lastName: String,
                         var schoolName: String,
                         var Address: String
)