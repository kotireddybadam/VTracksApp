package com.itok.vtracksapp.Bean

data class VaccinationProvidersInfo( var ProviderName: String,
                      var MailId: String,
                      var ContactNumber: String,
                      var Address: String)